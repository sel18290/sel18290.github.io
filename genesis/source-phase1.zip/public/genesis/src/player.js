import {composeRoom} from './compose.js';
import {GenesisBridge} from './bridge.js';
import {adapters} from './adapters.js';
import {validate} from './blueprint.js';
const $=id=>document.getElementById(id);
const bridge=new GenesisBridge(adapters), controller=new AbortController();
let space, scope;
async function run(){
  const name=new URLSearchParams(location.search).get('scene')||'resonance';
  if(!/^[a-z][a-z0-9-]{0,63}$/.test(name))throw Error('Identifiant de salle invalide');
  const response=await fetch('./scenes/'+name+'.json');
  if(!response.ok)throw Error('Salle introuvable');
  const definition=await response.json();
  const bp=validate(definition.modules?composeRoom(definition,await (await fetch('./scenes/modules.json')).json()):definition,adapters);
  $('title').textContent=bp.name;
  for(const transition of bp.transitions){const link=document.createElement('a');link.href=transition.to;link.textContent=transition.label;$('links').append(link);}
  if(name==='resonance'){const preview=document.createElement('a');preview.href='./?scene=n05';preview.textContent='Aperçu N05';$('links').append(' · ',preview);}
  if(bp.opening){
    const cover=$('cover'), image=$('plate'), enter=$('explore');
    image.alt=bp.opening.alt;image.src=bp.opening.image;
    $('cover-title').textContent=bp.name;
    await image.decode();cover.hidden=false;$('loading').hidden=true;
    await new Promise(resolve=>{enter.onclick=resolve;enter.focus();});
    cover.hidden=true;$('loading').hidden=false;
    $('review').hidden=false;$('review').onclick=()=>{
      space?.pause(true);cover.hidden=false;enter.textContent='Reprendre l’exploration';enter.focus();
      enter.onclick=()=>{cover.hidden=true;space?.pause(false);$('review').focus();};
    };
  }
  if(bp.mode!=='2d'){
    space=(await import('../spatial.bundle.js')).spatial($('world'),bp,controller.signal);
    document.body.classList.add('spatial');
  }
  const actions=new Map();
  function update(){
    for(const [button,item] of actions){
      const distance=space?Math.hypot(space.position.x-item.obj.position[0],space.position.z-item.obj.position[2]):0;
      button.hidden=distance>item.cfg.range;
    }
  }
  const view={...space,status:text=>$('progress').textContent=text,
    action(obj,cfg,activate){const button=document.createElement('button');button.textContent=cfg.label;button.onclick=activate;$('actions').append(button);actions.set(button,{obj,cfg});return ()=>{actions.delete(button);button.remove();};},
    panel(){space?.pause(true);if(!$('dialog').open)$('dialog').showModal();return $('archive');}
  };
  $('dialog').onclose=()=>space?.pause(false);
  $('close').onclick=()=>$('dialog').close();
  window.addEventListener('keydown',e=>{if($('cover').hidden&&e.code==='KeyE'&&!e.repeat&&!$('dialog').open){[...actions.keys()].find(b=>!b.hidden)?.click();}},{signal:controller.signal});
  $('audio').onclick=async()=>{const enabled=!bridge.host.enabled;await bridge.host.enable(enabled);$('audio').textContent=enabled?'Couper le son':'Activer le son';};
  scope=await bridge.enter(bp,view);
  $('loading').hidden=true;update();
  space?.start(dt=>{bridge.update(dt);update();});
}
function dispose(){controller.abort();bridge.exit();space?.dispose();bridge.host.dispose();}
addEventListener('pagehide',e=>{if(!e.persisted)dispose();},{once:true});
run().catch(e=>{dispose();$('loading').hidden=false;$('loading').textContent='Chargement interrompu · '+e.message;});
