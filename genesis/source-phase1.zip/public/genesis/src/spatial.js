import {sectorContains} from './sector-plan.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {createOrbitalView} from './orbital-view.js';
import * as T from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {SparkRenderer,SplatMesh} from '@sparkjsdev/spark';

export function spatial(canvas, blueprint, signal){
  const renderer=new T.WebGLRenderer({canvas,antialias:true});
  const mobile=matchMedia('(pointer:coarse)').matches;
  renderer.setPixelRatio(Math.min(devicePixelRatio,mobile?1.3:1.8));
  const scene=new T.Scene(),camera=new T.PerspectiveCamera(65,1,.05,1200);
  scene.background=new T.Color(0x17253b);camera.rotation.order='YXZ';
  camera.position.fromArray(blueprint.space.spawn);
  scene.add(new T.HemisphereLight(0xffe8d7,0x626674,2.4));
  const key=new T.DirectionalLight(0xffdfc5,2);key.position.set(1,4,3);scene.add(key);
  const obstacles=[...blueprint.space.obstacles],keys=new Set();
  let tickSector;
  let drag=null,stick=null,side=0,forward=0,paused=false;
  const on=(el,event,fn)=>el.addEventListener(event,fn,{signal});
  const clear=()=>{keys.clear();side=forward=0;drag=stick=null;};
  on(window,'blur',clear);
  on(window,'keydown',e=>{if(!paused && ['KeyW','KeyZ','KeyA','KeyQ','KeyS','KeyD','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.code)){keys.add(e.code);e.preventDefault();}});
  on(window,'keyup',e=>keys.delete(e.code));
  on(canvas,'pointerdown',e=>{if(paused)return;drag=[e.pointerId,e.clientX,e.clientY];canvas.setPointerCapture(e.pointerId);});
  on(canvas,'pointermove',e=>{
    if(drag?.[0]!==e.pointerId||paused)return;
    camera.rotation.y-=(e.clientX-drag[1])*.003;
    camera.rotation.x=T.MathUtils.clamp(camera.rotation.x-(e.clientY-drag[2])*.003,-1.45,1.45);
    drag=[e.pointerId,e.clientX,e.clientY];
  });
  on(canvas,'lostpointercapture',()=>drag=null);
  const pad=document.querySelector('#pad');
  function joystick(e){const r=pad.getBoundingClientRect();const x=(e.clientX-r.left-r.width/2)/(r.width/2),z=(e.clientY-r.top-r.height/2)/(r.height/2);const n=Math.max(1,Math.hypot(x,z));side=x/n;forward=-z/n;}
  on(pad,'pointerdown',e=>{stick=e.pointerId;pad.setPointerCapture(stick);joystick(e);});
  on(pad,'pointermove',e=>{if(stick===e.pointerId)joystick(e);});
  on(pad,'lostpointercapture',()=>{side=forward=0;stick=null;});
  const resize=()=>{renderer.setSize(innerWidth,innerHeight,false);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();};
  resize();on(window,'resize',resize);
  const walkable=blueprint.space.network==='orbital'?sectorContains:(x,z)=>Math.abs(x)<=blueprint.space.width/2-.24&&Math.abs(z)<=blueprint.space.depth/2-.24;
  const valid=(x,z)=>walkable(x,z)&&obstacles.every(([cx,cz,r])=>Math.hypot(x-cx,z-cz)>=r+.24);
  function move(dt){
    if(paused)return;
    const down=(...codes)=>Number(codes.some(c=>keys.has(c)));
    const x=side+down('KeyD','ArrowRight')-down('KeyA','KeyQ','ArrowLeft'),z=forward+down('KeyW','KeyZ','ArrowUp')-down('KeyS','ArrowDown');
    const distance=dt*2.2/Math.max(1,Math.hypot(x,z)),yaw=camera.rotation.y,p=camera.position;
    const dx=(Math.cos(yaw)*x-Math.sin(yaw)*z)*distance,dz=(-Math.sin(yaw)*x-Math.cos(yaw)*z)*distance;
    if(valid(p.x+dx,p.z))p.x+=dx;
    if(valid(p.x,p.z+dz))p.z+=dz;
  }
  return {
    mobile,position:camera.position, pause(value){paused=value;clear();},
    block(p,r){const item=[p[0],p[2],r];obstacles.push(item);return ()=>obstacles.splice(obstacles.indexOf(item),1);},
    async orbital(url){
      const texture=url?await new T.TextureLoader().loadAsync(url):null;
      if(texture)texture.colorSpace=T.SRGBColorSpace;
      const generator=new T.PMREMGenerator(renderer), studio=new RoomEnvironment();
      const reflection=generator.fromScene(studio,.04);studio.dispose();
      scene.environment=reflection.texture;scene.environmentIntensity=.85;
      const loader=new T.TextureLoader();
      const [map,roughnessMap,normalMap]=await Promise.all(['colour','rough','normal'].map(name=>loader.loadAsync('/genesis/assets/deck-'+name+'.png')));
      map.colorSpace=T.SRGBColorSpace;
      for(const layer of [map,roughnessMap,normalMap])layer.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());
      const probeScene=new T.Scene();probeScene.background=new T.Color(0x242c34);
      if(texture){
        const window=new T.Mesh(new T.PlaneGeometry(9.3,3.7),new T.MeshBasicMaterial({map:texture}));
        window.position.set(0,1.45,-5);probeScene.add(window);
      }
      const bayReflection=generator.fromScene(probeScene,.045);generator.dispose();
      for(const mesh of probeScene.children){mesh.geometry.dispose();mesh.material.dispose();}
      const environment=createOrbitalView(texture,{map,roughnessMap,normalMap},bayReflection.texture);scene.add(environment);tickSector=environment.userData.tickSector;
      // Local pools of light place the cold specimens and hot collector in silhouette.
      for(const [x,y,z,color,power,range] of [[-2,3.2,-4.6,0xffc88e,43,12],[-20,3.4,1,0x8ce1ed,66,11],[20,4,0,0xffab66,85,13],[1,3.6,32,0x9cbce4,45,10]]){
        const source=new T.PointLight(color,power,range,2);source.position.set(x,y,z);environment.add(source);
      }
      scene.children.find(node=>node.isHemisphereLight).intensity=1.15;
      renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;
      return ()=>{environment.userData.dispose();scene.environment=null;reflection.dispose();bayReflection.dispose();texture?.dispose();};
    },
    async model(url,position,height){
      const root=(await new GLTFLoader().loadAsync(url)).scene;
      const box=new T.Box3().setFromObject(root),s=height/(box.max.y-box.min.y);
      const center=box.getCenter(new T.Vector3());
      root.scale.multiplyScalar(s);root.position.set(position[0]-center.x*s,position[1]-box.min.y*s,position[2]-center.z*s);scene.add(root);
      return ()=>{root.removeFromParent();const resources=new Set();root.traverse(n=>{if(!n.isMesh)return;resources.add(n.geometry);for(const m of [].concat(n.material)){resources.add(m);for(const v of Object.values(m))if(v?.isTexture)resources.add(v);}});resources.forEach(r=>r.dispose());};
    },
    async splats(url,position){
      let spark=scene.getObjectByName('genesis-spark');
      if(!spark){spark=new SparkRenderer({renderer,depthTest:true,blurAmount:.12});spark.name='genesis-spark';scene.add(spark);}
      const volume=new SplatMesh({url});volume.position.fromArray(position);scene.add(volume);
      try{await volume.initialized;}catch(error){volume.removeFromParent();volume.dispose();throw error;}
      return {tint:value=>volume.recolor.setRGB(value, .91*value, .88*value),dispose:()=>{volume.removeFromParent();volume.dispose();}};
    },
    start(update){let previous;renderer.setAnimationLoop(time=>{const dt=Math.min(.05,(time-(previous??time))/1000);previous=time;move(dt);tickSector?.(dt);update(dt);renderer.render(scene,camera);});},
    dispose(){renderer.setAnimationLoop(null);scene.getObjectByName('genesis-spark')?.dispose();renderer.dispose();}
  };
}
