import {createRequire} from 'node:module';
import {resolve} from 'node:path';
const require=createRequire(resolve('public/spark-fusion/source-spark/package.json'));
const {build}=require('esbuild');
const result=await build({entryPoints:['public/genesis/src/spatial.js'],outfile:'public/genesis/spatial.bundle.js',bundle:true,minify:true,format:'esm',metafile:true,plugins:[{name:'shared-runtime',setup(api){
  for(const spec of ['three','three/addons/loaders/GLTFLoader.js','@sparkjsdev/spark']){
    api.onResolve({filter:new RegExp('^'+spec.replace(/[.*+?^$\x7b\x7d()|[\]\\]/g,'\\$&')+'$')},()=>({path:spec==='three'?require.resolve('three').replace('three.cjs','three.module.js'):spec==='@sparkjsdev/spark'?require.resolve(spec).replace('spark.cjs.js','spark.module.js'):require.resolve(spec)}));
  }
}}]});
if(Object.keys(result.metafile.inputs).filter(p=>p.endsWith('/three.core.js')).length!==1)throw Error('Noyau Three dupliqué');
