import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,statSync} from 'node:fs';
import {GenesisBridge} from '../public/genesis/src/bridge.js';
import {adapters} from '../public/genesis/src/adapters.js';
import {validate} from '../public/genesis/src/blueprint.js';
import {bindJourney} from '../public/genesis/src/journey.js';
const read=name=>JSON.parse(readFileSync('public/genesis/scenes/'+name+'.json'));
test('Blueprint hybride et modèle 2D, ressources présentes, extension inconnue rejetée',()=>{
 for(const name of ['template','resonance']){
  const b=read(name);validate(b,adapters);
  for(const url of Object.values(b.resources))assert.ok(statSync('public'+url).size>0);
  b.objects[0].components.inconnu={};assert.throws(()=>validate(b,adapters));
 }
});
test('Console catalogue → activation gaussienne → tablette → un objectif durable, nettoyage puis reprise',async()=>{
 const storage=new Map(),local={getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,v)};
 const engine=new GenesisBridge(adapters,local),bp=read('resonance');
 let activate,light,panelCount=0,releases=0,record,label,disabled;
 const release=()=>releases++;
 const view={model:async()=>release,block:()=>release,splats:async()=>({dispose:release,tint:x=>light=x}),action:(_o,_c,fn)=>{activate=fn;return release;},panel:()=>{panelCount++;return element();},status:s=>label=s};
 function element(){return {children:[],dataset:{},append(...args){this.children.push(...args);},replaceChildren(){},setAttribute(){},querySelectorAll(){return [];},set id(v){if(v==='science-read')record=this;},set disabled(v){disabled=v;}};}
 globalThis.document={createElement:element,createTextNode:t=>t};
 try{
 await engine.enter(bp,view);engine.update(.02);const initial=light;activate();engine.update(.05);
 assert.ok(light>initial);assert.equal(panelCount,1);record.onclick();assert.equal(storage.size,1);assert.equal(label,'Lecture enregistrée');
 engine.exit();assert.equal(engine.core.events.count(),0);assert.equal(releases,4);
 await engine.enter(bp,view);activate();assert.equal(disabled,true);
 }finally{engine.exit();delete globalThis.document;}
});
test('Passage et retour Spark utilisent la session existante et filtrent les messages étrangers',()=>{
 const host=new EventTarget(),frame={contentWindow:{}},entries=[],saves=[];
 globalThis.window=host;globalThis.location={origin:'https://example.test'};
 let current='noctis';const controller=new AbortController();
 const send=(type,origin=location.origin)=>{const event=new Event('message');Object.assign(event,{source:frame.contentWindow,origin,data:{type}});host.dispatchEvent(event);};
 try{bindJourney({frame,active:()=>current,signal:controller.signal,session:{complete:id=>saves.push(id)},route:id=>{current=id;entries.push(id);},ready:()=>entries.push('ready')});
 send('fusion:passage','https://other.test');send('cortex:n04');assert.equal(entries.length,0);
 send('fusion:passage');send('cortex:n04');send('spark:ready');assert.deepEqual(entries,['east','n04','ready']);assert.deepEqual(saves,['secret-passage']);
 }finally{controller.abort();delete globalThis.window;delete globalThis.location;}
});
test('N05 assemble N01 à N04 et conserve un identifiant de progression distinct',async()=>{
 const {composeRoom}=await import('../public/genesis/src/compose.js');
 const b=validate(composeRoom(read('n05'),read('modules')),adapters);
 assert.equal(b.id,'n05-apercu');assert.equal(b.opening,undefined);assert.ok(statSync('public'+b.resources.observatoire).size>1000);
 assert.equal(b.objects.find(o=>o.id==='document').components.archive.trigger,'terminal');
 assert.ok(b.objects.some(o=>o.components.gaussian));assert.ok(b.objects.some(o=>o.components.catalogue));
});
test('N05 utilise un vrai volume propre et une baie 3D avec des géométries finies',async()=>{
 const {composeRoom}=await import('../public/genesis/src/compose.js');
 const b=composeRoom(read('n05'),read('modules'));
 for(const key of ['observatoire','observatoire-mobile']){
   const data=readFileSync('public'+b.resources[key]);
   assert.equal(data.length%32,0);
   for(let offset=0;offset<data.length;offset+=32)for(let k=0;k<6;k++){
     const value=data.readFloatLE(offset+k*4);assert.ok(Number.isFinite(value));
     if(k>=3)assert.ok(value>0);
   }
 }
 const {createOrbitalView}=await import('../public/genesis/src/orbital-view.js');
 const root=createOrbitalView();
 let instances=0;
 root.traverse(o=>{if(o.isMesh){if(o.isInstancedMesh)instances+=o.count;for(const n of o.geometry.attributes.position.array)assert.ok(Number.isFinite(n));}});
 assert.ok(instances>0);
 const terminal=b.objects.find(o=>o.id==='terminal');
 assert.ok(terminal.position[0]-terminal.components.collider.radius>0,'Axe de circulation libre devant la baie');
 root.userData.dispose();
});
test('Deux boucles physiques et branche atlas avec les obstacles N05',async()=>{
 const {sectorContains}=await import('../public/genesis/src/sector-plan.js');
 const {composeRoom}=await import('../public/genesis/src/compose.js');
 const room=composeRoom(read('n05'),read('modules'));
 const obstacles=[...room.space.obstacles,...room.objects.filter(o=>o.components.collider).map(o=>[o.position[0],o.position[2],o.components.collider.radius])];
 const paths=[
 [[0,2],[-18,2],[-18,20],[1,20],[1,2],[0,2]],
 [[0,3],[18,3],[18,20],[1,20],[1,2],[0,2]],
 [[1,20],[1,29],[4,29],[4,31],[4,29],[1,29],[1,20]]
 ];
 for(const path of paths)for(let k=1;k<path.length;k++){
   const [x,z]=path[k-1],[tx,tz]=path[k];
   for(let i=0;i<=200;i++){const px=x+(tx-x)*i/200,pz=z+(tz-z)*i/200;
     assert.ok(sectorContains(px,pz)&&obstacles.every(([cx,cz,r])=>Math.hypot(cx-px,cz-pz)>r+.24),[px,pz].join(','));
   }
 }
 assert.equal(sectorContains(9,8),false);
});
